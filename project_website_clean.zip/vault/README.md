# 🏠 Kalasin Real Estate & FastLED Platform - Obsidian Vault

ยินดีต้อนรับสู่คลังเอกสารสถาปัตยกรรมและการวิเคราะห์ระบบ (Obsidian Knowledge Base) สำหรับโครงการ:
**"เว็บไซต์และแอปพลิเคชันตลาดอสังหาริมทรัพย์ ทรัพย์บังคับคดี และสิ่งปลูกสร้างไม้เก่า จังหวัดกาฬสินธุ์"**

---

## 🗺️ แผนผังเอกสารใน Vault (Documentation Sitemap)

### 📋 1. ข้อกำหนดความต้องการของระบบ (Software Requirements Specification: SRS)
- [[01_SRS_Software_Requirements_Specification]]
  - ภาพรวมวัตถุประสงค์และขอบเขตระบบ (Scope & Purpose)
  - ผู้ใช้งานระบบและกลุ่มเป้าหมาย (User Personas & Roles)
  - ข้อกำหนดเชิงหน้าที่ (Functional Requirements: FR)
    - FR-01: Smart Search & Filter (18 อำเภอ 133 ตำบล)
    - FR-02: FastLEDChecker Analytics Engine (Max Bid & Debt Calculation)
    - FR-03: Wood Valuation Engine & Submission Marketplace
    - FR-04: Geospatial Information System (GIS Interactive Map)
    - FR-05: Side-by-Side Property Comparison
  - ข้อกำหนดเชิงคุณภาพ (Non-Functional Requirements: NFR)
    - ประสิทธิภาพ (Performance), ความปลอดภัย (Security), ความพร้อมใช้งาน (Availability)

### 🏗️ 2. สถาปัตยกรรมระบบ (System Architecture)
- [[02_System_Architecture]]
  - ภาพรวมสถาปัตยกรรม (System Context & Architecture Diagram)
  - สถาปัตยกรรม Next.js App Router (Client-Side vs Server-Side Components)
  - Data Pipeline & External Integration (FastLEDChecker / กรมบังคับคดี LED)
  - เครื่องมือวิเคราะห์เชิงประมวลผล (FastLED Analytics Engine Workflow)
  - เครือข่ายและการให้บริการ (Deployment, Reverse Proxy & Local Runtime)

### 🗄️ 3. การออกแบบฐานข้อมูล (Database Schema & Data Model)
- [[03_Database_Schema]]
  - ภาพรวมการจัดการฐานข้อมูล (Prisma ORM with SQLite / PostgreSQL Compatible)
  - แผนภาพความสัมพันธ์เชิงข้อมูล (Entity Relationship Diagram: ERD)
  - รายละเอียด Data Dictionary ตาราง `Property` (ทรัพย์บังคับคดีและบ้านไม้เก่า)
  - รายละเอียด Data Dictionary ตาราง `Contractor` (ผู้รับเหมาและช่างรื้อถอน)
  - ระบบ Seed / Mockup Data Pipeline (900 รายการจริง)
  - ตัวอย่าง Prisma Schema Definition (`schema.prisma`)

---

## 📚 เอกสารบทที่ 1 เดิม (Thesis Chapter 1 Vault)
- [[1.1_ที่มาและความสำคัญ]]
- [[1.2_วัตถุประสงค์ของโครงการ]]
- [[1.3_ขอบเขตของโครงการ]]
- [[1.4_ผลที่คาดว่าจะได้รับ]]
- [[1.5_เครื่องมือและเทคโนโลยีที่ใช้ในการดำเนินงาน]]
- [[บทที่ 1]]
