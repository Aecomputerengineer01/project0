# 🗄️ การออกแบบฐานข้อมูล (Database Schema & Data Model)

**โครงการ:** เว็บไซต์และแอปพลิเคชันตลาดอสังหาริมทรัพย์ ทรัพย์บังคับคดี และสิ่งปลูกสร้างไม้เก่า จังหวัดกาฬสินธุ์  
**ระบบจัดการฐานข้อมูล (DBMS):** SQLite (Local/Development) / PostgreSQL Compatible  
**เครื่องมือจัดการ (ORM):** Prisma ORM (Version 6.4.1)  
**จำนวนข้อมูลตั้งต้น (Seed Data):** 900 รายการจริง ครอบคลุม 18 อำเภอ 133 ตำบล  

---

## 1. แผนภาพความสัมพันธ์เชิงข้อมูล (Entity Relationship Diagram: ERD)

```mermaid
erDiagram
    PROPERTY ||--o{ WOOD_DETAIL : "has optional valuation"
    PROPERTY {
        string id PK "รหัสทรัพย์สิน (เช่น KLS-LED-..., KLS-WOOD-...)"
        string title "ชื่อรายการทรัพย์สิน"
        string type "ประเภท (led_asset, wooden_building, normal)"
        string assetCategory "หมวดหมู่ทรัพย์ (ที่ดินพร้อมสิ่งปลูกสร้าง, บ้านไม้)"
        string district "อำเภอ (18 อำเภอในกาฬสินธุ์)"
        string subdistrict "ตำบล (133 ตำบล)"
        string address "ที่ตั้งทางกายภาพ"
        string deedNo "เลขที่โฉนดที่ดิน"
        float priceStarting "ราคาเริ่มต้นประมูล / ราคาขาย"
        float priceAppraised "ราคาประเมินเจ้าพนักงาน"
        float marketEstimate "ราคาตลาดประมาณการ"
        float mortgageDebt "ยอดภาระจำนองติดไป"
        float realTotalPayment "ราคาจริงที่ต้องจ่าย (เคาะ+จำนอง)"
        string auctionDate "วันนัดประมูล"
        string competitorStatus "สถานะการแข่งขัน"
        boolean isMortgageAttached "มีภาระจำนองติดไปหรือไม่"
        string evictionRisk "ความเสี่ยงการขับไล่ (low, medium, high, none)"
        float evictionCostEst "ประมาณการค่าใช้จ่ายฟ้องขับไล่"
        float renovationCostEst "ประมาณการค่าปรับปรุง"
        float areaSqW "ขนาดที่ดิน (ตารางวา)"
        float usableAreaSqM "พื้นที่ใช้สอย (ตารางเมตร)"
        float lat "พิกัดละติจูด (GIS)"
        float lng "พิกัดลองจิจูด (GIS)"
        string status "สถานะทรัพย์สิน"
        string ledCourt "ศาลที่ออกหมายบังคับคดี"
        string ledCaseNo "หมายเลขคดีแดง"
        float reserveFund "เงินวางประกันเข้าประมูล"
        string saleLocation "สถานที่ขายทอดตลาด"
        string dataSourceUrl "ลิงก์อ้างอิงข้อมูลต้นทาง"
        string images "URL รูปภาพ (JSON Array)"
        string features "จุดเด่นและคุณสมบัติ (JSON Array)"
        string contactName "ชื่อผู้ติดต่อ"
        string contactPhone "เบอร์โทรศัพท์ผู้ติดต่อ"
        boolean hasExistingStructure "มีสิ่งปลูกสร้างบนที่ดินหรือไม่"
        string woodType "ชนิดไม้หลัก"
        float woodVolumeCubicM "ปริมาตรไม้ (ลบ.ม.)"
        int woodPillars "จำนวนเสาเรือน"
        float woodConditionPercent "สภาพเนื้อไม้ (%)"
        float woodValueEstimate "มูลค่าเนื้อไม้ประเมินสุทธิ"
        string salvageFeasibility "ผลประเมินความคุ้มค่าการรื้อถอน"
        boolean isUserSubmitted "รายการลงประกาศโดยประชาชนหรือไม่"
        datetime createdAt "วันที่บันทึกเข้าระบบ"
        datetime updatedAt "วันที่แก้ไขล่าสุด"
    }

    CONTRACTOR {
        string id PK "รหัสช่าง/ผู้รับเหมา (เช่น C01, C02)"
        string name "ชื่อทีมช่าง / ผู้รับเหมา"
        string district "พื้นที่ประจำการ (อำเภอ)"
        string phone "เบอร์โทรศัพท์ติดต่อ"
        int experienceYears "ประสบการณ์ทำงาน (ปี)"
        string specialty "ความเชี่ยวชาญเฉพาะด้าน"
        float rating "คะแนนรีวิว (1-5 ดาว)"
        int reviewsCount "จำนวนรีวิว"
        int completedJobs "ผลงานที่ส่งมอบแล้ว"
        datetime createdAt "วันที่ขึ้นทะเบียน"
    }
```

---

## 2. พจนานุกรมข้อมูล (Data Dictionary)

### 2.1 ตาราง `Property` (ตารางทรัพย์สินและสิ่งปลูกสร้าง)

| ชื่อฟิลด์ | ชนิดข้อมูล | เงื่อนไข | คำอธิบาย | ตัวอย่างข้อมูล |
| :--- | :--- | :--- | :--- | :--- |
| `id` | String | Primary Key | รหัสเฉพาะของทรัพย์สิน | `"KLS-LED-2104616"` |
| `title` | String | Not Null | หัวข้อหรือชื่อประกาศทรัพย์สิน | `"ที่ดินพร้อมสิ่งปลูกสร้าง ต.หนองกุงศรี"` |
| `type` | String | Not Null | ประเภททรัพย์สิน (`led_asset`, `wooden_building`, `normal`) | `"led_asset"` |
| `assetCategory`| String | Not Null | หมวดหมู่สิ่งปลูกสร้าง | `"ที่ดินพร้อมสิ่งปลูกสร้าง"` |
| `district` | String | Not Null | อำเภอในจังหวัดกาฬสินธุ์ (18 อำเภอ) | `"หนองกุงศรี"` |
| `subdistrict` | String | Not Null | ตำบลในอำเภอนั้นๆ (133 ตำบล) | `"หนองกุงศรี"` |
| `address` | String | Not Null | ที่อยู่และรายละเอียดที่ตั้ง | `"ต.หนองกุงศรี อ.หนองกุงศรี จ.กาฬสินธุ์"` |
| `deedNo` | String | Not Null | เลขที่โฉนดที่ดิน / เลขระวาง | `"โฉนด 45892"` |
| `priceStarting`| Float | Not Null | ราคาเริ่มต้นเคาะประมูล หรือราคาเสนอขาย | `450000.0` |
| `priceAppraised`| Float | Not Null | ราคาประเมินของเจ้าพนักงาน | `600000.0` |
| `marketEstimate`| Float | Not Null | ราคาตลาดประเมินโดยระบบ | `720000.0` |
| `mortgageDebt` | Float | Default: 0 | ยอดภาระหนี้จำนองติดไปตามสัญญา | `150000.0` |
| `realTotalPayment`| Float | Not Null | ราคาจริงที่ต้องจ่าย (`priceStarting + mortgageDebt`)| `600000.0` |
| `auctionDate` | String | Nullable | วันเวลานัดขายทอดตลาด | `"นัดที่ 1: 15 ต.ค. 2569"` |
| `isMortgageAttached`| Boolean | Default: false | ตัวแปรบอกสถานะว่ามีภาระจำนองติดไปหรือไม่ | `true` |
| `evictionRisk` | String | Default: "low" | ระดับความเสี่ยงในการฟ้องขับไล่ (`low`, `medium`, `high`, `none`) | `"medium"` |
| `lat` | Float | Not Null | พิกัดละติจูดสำหรับแผนที่ GIS | `16.6520` |
| `lng` | Float | Not Null | พิกัดลองจิจูดสำหรับแผนที่ GIS | `103.3050` |
| `ledCaseNo` | String | Nullable | หมายเลขคดีแดงของกรมบังคับคดี | `"ผบ.142/2566"` |
| `images` | String | Not Null | รายการ URL ภาพถ่าย (จัดเก็บแบบ JSON Array String) | `["https://..."]` |
| `woodType` | String | Nullable | ชนิดไม้หลัก (กรณีเป็นสิ่งปลูกสร้างไม้เก่า) | `"ไม้สัก (Teak)"` |
| `woodVolumeCubicM`| Float | Nullable | ปริมาตรเนื้อไม้เป็นลูกบาศก์เมตร | `18.5` |
| `woodPillars` | Int | Nullable | จำนวนเสาเรือนโบราณ | `16` |
| `woodValueEstimate`| Float | Nullable | มูลค่าเนื้อไม้ประเมินสุทธิ | `380000.0` |
| `isUserSubmitted`| Boolean| Default: false| ตรวจสอบว่าเป็นการลงประกาศโดยประชาชนหรือไม่ | `false` |

---

### 2.2 ตาราง `Contractor` (ตารางผู้รับเหมาและบริการช่างรื้อถอน)

| ชื่อฟิลด์         | ชนิดข้อมูล | เงื่อนไข     | คำอธิบาย                                            |
| :---------------- | :--------- | :----------- | :-------------------------------------------------- |
| `id`              | String     | Primary Key  | รหัสประจำตัวผู้รับเหมา                              |
| `name`            | String     | Not Null     | ชื่อทีมช่าง หรือชื่อห้างหุ้นส่วนจำกัด               |
| `district`        | String     | Not Null     | อำเภอหลักที่ให้บริการในกาฬสินธุ์                    |
| `phone`           | String     | Not Null     | เบอร์โทรศัพท์สำหรับติดต่อสอบถาม                     |
| `experienceYears` | Int        | Not Null     | ประสบการณ์ทำงานด้านรื้อถอน/ประกอบไม้ (ปี)           |
| `specialty`       | String     | Not Null     | ความเชี่ยวชาญเด่น (เช่น รื้อถอนโบราณ, ขนย้ายไม้สัก) |
| `rating`          | Float      | Default: 4.5 | คะแนนความพึงพอใจของลูกค้า (1-5 ดาว)                 |
| `reviewsCount`    | Int        | Default: 0   | จำนวนครั้งที่ได้รับการรีวิว                         |
| `completedJobs`   | Int        | Nullable     | จำนวนงานรื้อถอนที่ส่งมอบงานสำเร็จ                   |

---

## 3. โค้ดนิยามโมเดลภาษา Prisma (`schema.prisma`)

```prisma
datasource db {
  provider = "sqlite"
  url      = env("DATABASE_URL")
}

generator client {
  provider = "prisma-client-js"
}

model Property {
  id                   String   @id
  title                String
  type                 String
  assetCategory        String
  district             String
  subdistrict          String
  address              String
  deedNo               String
  priceStarting        Float
  priceAppraised       Float
  marketEstimate       Float
  mortgageDebt         Float    @default(0)
  realTotalPayment     Float
  auctionDate          String?
  competitorStatus     String?
  isMortgageAttached   Boolean  @default(false)
  evictionRisk         String   @default("low")
  evictionCostEst      Float    @default(0)
  renovationCostEst    Float    @default(0)
  areaSqW              Float    @default(0)
  usableAreaSqM        Float    @default(0)
  lat                  Float
  lng                  Float
  status               String
  ledCourt             String?
  ledCaseNo            String?
  reserveFund          Float    @default(50000)
  saleLocation         String?
  dataSourceUrl        String?
  images               String
  features             String
  contactName          String?
  contactPhone         String?
  hasExistingStructure Boolean  @default(false)
  woodType             String?
  woodVolumeCubicM     Float?
  woodPillars          Int?
  woodConditionPercent Float?
  woodValueEstimate    Float?
  salvageFeasibility   String?
  isUserSubmitted      Boolean  @default(false)
  createdAt            DateTime @default(now())
  updatedAt            DateTime @updatedAt
}

model Contractor {
  id              String   @id
  name            String
  district        String
  phone           String
  experienceYears Int
  specialty       String
  rating          Float    @default(4.5)
  reviewsCount    Int      @default(0)
  completedJobs   Int?     @default(0)
  createdAt       DateTime @default(now())
}
```

---

## 4. กลยุทธ์การ Seed ข้อมูลและการบำรุงรักษา (Data Pipeline Strategy)

1. **Pure Authentic Seed Data:**
   - นำเข้าข้อมูลจริง 100% จำนวน **900 รายการ** ที่ผ่านการคัดกรองข้อมูลจำลองออก จาก `fastled_full_sync.json`
   - แบ่งการบันทึกข้อมูลเป็น Batch ละ 100 รายการ ด้วย `$transaction` เพื่อความรวดเร็วและคงสภาพความสมบูรณ์ของฐานข้อมูล (ACID Properties)
2. **เครื่องมือบริหารจัดการข้อมูล:**
   - สามารถเปิดใช้ **Prisma Studio** เพื่อดูและแก้ไขข้อมูลผ่านหน้าต่างเว็บเบราว์เซอร์ได้ทันทีผ่านคำสั่ง:
     ```bash
     npx prisma studio
     ```
