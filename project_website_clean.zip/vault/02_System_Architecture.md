# 🏗️ สถาปัตยกรรมระบบ (System Architecture)

**โครงการ:** เว็บไซต์และแอปพลิเคชันตลาดอสังหาริมทรัพย์ ทรัพย์บังคับคดี และสิ่งปลูกสร้างไม้เก่า จังหวัดกาฬสินธุ์  
**สถาปัตยกรรมหลัก:** Jamstack / Next.js Hybrid Architecture (Client Components, Server-Side API, Prisma ORM, Embedded Database)

---

## 1. ภาพรวมสถาปัตยกรรมระบบ (High-Level System Context)

ระบบถูกออกแบบเป็น **Full-Stack Next.js Architecture** ที่ผสมผสานความเร็วในการเรนเดอร์แบบ Client-side Interactivity และความเสถียรของ Server-Side API Routes ควบคู่กับฐานข้อมูล SQLite ผ่าน Prisma ORM

```mermaid
graph TB
    subgraph Client_Layer["🖥️ Client Layer (Browser)"]
        UI["Next.js React UI / Tailwind CSS"]
        CatalogComp["Catalog & Smart Filter (18 อำเภอ 133 ตำบล)"]
        AnalyticsComp["FastLEDChecker Calculator & Charts"]
        WoodComp["Wood Valuation & Submission Form"]
        GISComp["Leaflet GIS Interactive Map"]
        CompareComp["Compare Drawer & Modal"]
    end

    subgraph Application_Layer["⚙️ Application Layer (Next.js App Router)"]
        NextServer["Next.js Node.js Runtime"]
        PageRouter["Page Routes (src/app/page.tsx)"]
        APIRouter["API Handlers (/api/properties/route.ts)"]
        Engines["Analytics Core (FastLEDCheckerEngine & WoodPricing)"]
    end

    subgraph Data_Layer["🗄️ Data & Persistence Layer"]
        PrismaClient["Prisma Client ORM (Type-Safe)"]
        SQLiteDB[("SQLite Database (dev.db)")]
        StaticJSON[("fastled_full_sync.json (900 Real Records)")]
    end

    subgraph External_Layer["🌐 External Integration"]
        LED["กรมบังคับคดี (LED Web Service)"]
        FastLED["FastLEDChecker.com Data Source"]
        OSM["OpenStreetMap Tiles Service"]
    end

    UI --> PageRouter
    CatalogComp --> Engines
    AnalyticsComp --> Engines
    WoodComp --> APIRouter
    GISComp --> OSM
    CompareComp --> Engines

    PageRouter --> NextServer
    APIRouter --> PrismaClient
    PrismaClient --> SQLiteDB
    NextServer --> StaticJSON

    External_Layer -. Crawler Pipeline .-> StaticJSON
```

---

## 2. โครงสร้างและการแบ่งเลเยอร์ซอฟต์แวร์ (Layered Architecture)

### 2.1 Presentation Layer (Frontend - React 19 / Next.js 16)
- **Framework:** Next.js App Router พร้อม TypeScript
- **Styling:** Tailwind CSS v4 สำหรับ Responsive Layout, Custom Badges (`.badge-led`, `.badge-wood`)
- **Icons & UI:** `lucide-react` สำหรับไอคอนเชิงหน้าที่ (MapPin, Scale, TreePine, Wrench ฯลฯ)
- **GIS Mapping:** `leaflet` โหลดผ่าน `next/dynamic` แบบปิด SSR (`{ ssr: false }`) เพื่อความปลอดภัยในการทำงานกับ Window Object

### 2.2 Business Logic & Calculation Layer (FastLED & Wood Engine)
- **FastLEDCheckerEngine (`src/lib/fastled_engine.ts`):**
  - ฟังก์ชัน `calculateMaxBid()`: คำนวณเพดานประมูลสูงสุด
  - ฟังก์ชัน `calculateImplicitCosts()`: คำนวณภาษีโอน 2%, ภาษีหัก ณ ที่จ่าย 1%, อากร 0.5%, ค่าขับไล่
  - ฟังก์ชัน `calculateWoodValuation()`: คำนวณมูลค่าเนื้อไม้ตามปริมาตร ชนิดไม้ และโบนัสเสาเรือน
- ทำงานแบบ Isomorphic Logic (สามารถรันได้ทั้งบน Client เพื่อความเร็วแบบ Real-time และบน Server ก่อนบันทึกลง Database)

### 2.3 API & Service Layer (Route Handlers)
- **`GET /api/properties`**:
  - รองรับการสืบค้นข้อมูลจากฐานข้อมูลผ่าน Prisma ORM
  - รองรับ Query Parameters: `district`, `subdistrict`, `type`, `keyword`, `limit`
- **`POST /api/properties`**:
  - รองรับการบันทึกรายการประกาศขายบ้านไม้เก่าจากประชาชน (`isUserSubmitted: true`)

### 2.4 Data Persistence Layer (Prisma ORM & SQLite)
- **Prisma Client (`@prisma/client`):** จัดการ Query แบบ Type-safe ป้องกัน SQL Injection
- **SQLite (`dev.db`):** ฐานข้อมูล Embedded ไร้ภาระการคอนฟิก สามารถ Migrate ไปสู่ PostgreSQL หรือ MySQL ได้ทันทีเพียงเปลี่ยน Connection URL ใน `.env`

---

## 3. ผังการทำงานของระบบประเมินราคาประมูล (FastLED Analysis Flow)

```mermaid
sequenceDiagram
    autonumber
    actor User as นักลงทุน / ผู้ซื้อ
    participant UI as Smart Filter / Property Card
    participant Engine as FastLEDChecker Engine
    participant Modal as Property Detail Modal
    
    User->>UI: คลิกดูรายละเอียดทรัพย์สิน
    UI->>Engine: ส่งค่า (ราคาตลาด, ราคาเคาะ, ภาระหนี้จำนองติดไป, ความเสี่ยงขับไล่)
    Engine->>Engine: คำนวณเพดานประมูล Max Bid
    Engine->>Engine: คำนวณต้นทุนแฝง (ภาษีโอน + ภาษีหัก ณ ที่จ่าย + อากร + ค่าฟ้องขับไล่)
    Engine-->>Modal: ส่งผลลัพธ์การประเมิน
    Modal-->>User: แสดงการแจ้งเตือนความเสี่ยง (หนี้จำนอง) และสรุปกำไรคาดหวัง
```

---

## 4. ผังการลงประกาศบ้านไม้เก่าและการประเมินมูลค่า (Wood Submission Flow)

```mermaid
sequenceDiagram
    autonumber
    actor Seller as เจ้าของบ้านไม้เก่า
    participant Modal as WoodSubmissionModal
    participant Engine as Wood Valuation Engine
    participant API as Next.js API (/api/properties)
    participant DB as SQLite (via Prisma)

    Seller->>Modal: เลือกชนิดไม้, ปริมาตร (ลบ.ม.), เสา, สภาพเนื้อไม้ (%)
    Modal->>Engine: คำนวณมูลค่าเนื้อไม้แบบ Real-time
    Engine-->>Modal: แสดงมูลค่าประเมินสุทธิ + ช่วงราคาแนะนำ
    Seller->>Modal: กดยืนยันการลงประกาศ
    Modal->>API: ส่งข้อมูล HTTP POST
    API->>DB: บันทึกข้อมูลลงตาราง Property
    DB-->>API: ยืนยันบันทึกสำเร็จ
    API-->>Modal: Response Success (HTTP 200)
    Modal-->>Seller: อัปเดตรายการใหม่ขึ้นหน้าเว็บและแผนที่ GIS ทันที
```

---

## 5. การติดตั้งและการให้บริการ (Deployment Architecture)

1. **Development Runtime:**
   - Next.js Web: `http://localhost:3000`
   - Prisma Studio Management: `http://localhost:5555`
2. **Production Capability:**
   - รองรับการ Export เป็น Standalone Docker Container หรือ Deploy ขึ้น Vercel, Railway, หรือ VPS ภายในมหาวิทยาลัย
   - ฐานข้อมูลสามารถเชื่อมต่อไปยัง Cloud Managed PostgreSQL (Supabase, Neon, AWS RDS) ได้โดยตรง
